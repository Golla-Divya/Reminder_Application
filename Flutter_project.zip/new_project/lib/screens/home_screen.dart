// import 'package:flutter/material.dart';



// class HomeScreen extends StatelessWidget {
//   static const routeName = '/home-screen';

//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar : AppBar(title : Text('Task Manager')), 
//       body: Center(
//         child : Text('No Tasks added yet!'),
//       ),
//       floatingActionButton: FloatingActionButton(
//         child:Icon(
//           Icons.add,
//           color : Colors.white,
//       ),
//         backgroundColor: Colors.blue,
//         onPressed: () => showModalBottomSheet(
//           context :context,
//           builder : (BuildContext context) => Container(
//             color :Colors.blue[200],
//             child :Column(
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                   children: [
//                     Text(
//                       'Add task',
//                       style :GoogleFonts.montserrat(
//                         color : Colors.white,
//                         fontSize : 20.0,
//                       ),
//                     ),
//                     GestureDetector(
//                       onTap: () => Navigator.of(context).pop(),
//                     ),
//                   ],

//                 )
//               ],
//               ),


            
//           ),

//         ),
//       ),

      
//     );
//   }
// }